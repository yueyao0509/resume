#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#define HASH_TABLE_SIZE 1024
#define PATH_MAX 1000

struct Node {
    char *word;
    int count;
    struct Node *next;
};

struct HashTable {
    struct Node **buckets;
    int size;
};

struct FileData {
    char *filename;
    struct HashTable *word_counts;
    size_t total_words;
    struct FileData *next;
};

unsigned long compute_hash(const char *str) {
    unsigned long hash = 5381;
    int c;
    while ((c = *str++)) {
        hash = ((hash << 5) + hash) + c; // hash * 33 + c
    }
    return hash;
}

struct HashTable *create_hash_table(int size) {
    struct HashTable *ht = malloc(sizeof(struct HashTable));
    ht->size = size;
    ht->buckets = calloc(size, sizeof(struct Node *));
    return ht;
}

void free_hash_table(struct HashTable *ht) {
    if (!ht) return;
    for (int i = 0; i < ht->size; i++) {
        struct Node *node = ht->buckets[i];
        while (node) {
            struct Node *next = node->next;
            free(node->word);
            free(node);
            node = next;
        }
    }
    free(ht->buckets);
    free(ht);
}

struct Node *hash_table_insert(struct HashTable *ht, const char *word) {
    unsigned long hash = compute_hash(word);
    int index = hash % ht->size;
    struct Node *node = ht->buckets[index];
    while (node) {
        if (strcmp(node->word, word) == 0) {
            return node;
        }
        node = node->next;
    }
    struct Node *new_node = malloc(sizeof(struct Node));
    new_node->word = strdup(word);
    new_node->count = 0;
    new_node->next = ht->buckets[index];
    ht->buckets[index] = new_node;
    return new_node;
}

struct Node *hash_table_find(struct HashTable *ht, const char *word) {
    unsigned long hash = compute_hash(word);
    int index = hash % ht->size;
    struct Node *node = ht->buckets[index];
    while (node) {
        if (strcmp(node->word, word) == 0) {
            return node;
        }
        node = node->next;
    }
    return NULL;
}

int is_forbidden_start(char c) {
    return c == '(' || c == '[' || c == '{' || c == '"' || c == '\'';
}

int is_forbidden_end(char c) {
    return c == ')' || c == ']' || c == '}' || c == '"' || c == '\'' || c == ',' || c == '.' || c == '!' || c == '?';
}

void process_file(const char *filename, struct HashTable *global_table, size_t *global_total_words, struct FileData **file_list_head, struct FileData **file_list_tail) {
    int fd = open(filename, O_RDONLY);
    if (fd == -1) {
        perror(filename);
        return;
    }

    struct stat st;
    if (fstat(fd, &st) == -1) {
        perror(filename);
        close(fd);
        return;
    }

    if (!S_ISREG(st.st_mode)) {
        fprintf(stderr, "%s: not a regular file\n", filename);
        close(fd);
        return;
    }

    size_t file_size = st.st_size;
    char *buffer = malloc(file_size + 1);
    if (!buffer) {
        perror("malloc");
        close(fd);
        return;
    }

    ssize_t bytes_read = read(fd, buffer, file_size);
    if (bytes_read == -1) {
        perror(filename);
        free(buffer);
        close(fd);
        return;
    }

    if ((size_t)bytes_read != file_size) {
        fprintf(stderr, "%s: read incomplete\n", filename);
        free(buffer);
        close(fd);
        return;
    }
    buffer[bytes_read] = '\0';

    struct HashTable *file_table = create_hash_table(HASH_TABLE_SIZE);
    size_t file_total_words = 0;

    char *p = buffer;
    while (*p) {
        while (*p && isspace((unsigned char)*p)) p++;
        if (!*p) break;

        char *start = p;
        while (*p && !isspace((unsigned char)*p)) p++;
        char *end = p - 1;

        char *left = start;
        while (left <= end && is_forbidden_start(*left)) left++;
        char *right = end;
        while (right >= left && is_forbidden_end(*right)) right--;

        if (left > right) continue;

        int has_alpha = 0;
        for (char *c = left; c <= right; c++) {
            if (isalpha((unsigned char)*c)) {
                has_alpha = 1;
                break;
            }
        }
        if (!has_alpha) continue;

        size_t len = right - left + 1;
        char *word = malloc(len + 1);
        strncpy(word, left, len);
        word[len] = '\0';

        for (char *c = word; *c; c++) {
            *c = tolower((unsigned char)*c);
        }

        struct Node *file_node = hash_table_insert(file_table, word);
        file_node->count++;
        file_total_words++;

        struct Node *global_node = hash_table_insert(global_table, word);
        global_node->count++;

        free(word);
    }

    free(buffer);
    close(fd);

    if (file_total_words == 0) {
        free_hash_table(file_table);
        return;
    }

    struct FileData *fdata = malloc(sizeof(struct FileData));
    fdata->filename = strdup(filename);
    fdata->word_counts = file_table;
    fdata->total_words = file_total_words;
    fdata->next = NULL;

    if (*file_list_tail) {
        (*file_list_tail)->next = fdata;
        *file_list_tail = fdata;
    } else {
        *file_list_head = fdata;
        *file_list_tail = fdata;
    }

    *global_total_words += file_total_words;
}

void process_directory(const char *path, struct HashTable *global_table, size_t *global_total_words, struct FileData **file_list_head, struct FileData **file_list_tail);

void traverse_directory(const char *path, struct HashTable *global_table, size_t *global_total_words, struct FileData **file_list_head, struct FileData **file_list_tail) {
    DIR *dir = opendir(path);
    if (!dir) {
        perror(path);
        return;
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_name[0] == '.') continue;

        char full_path[PATH_MAX];
        snprintf(full_path, PATH_MAX, "%s/%s", path, entry->d_name);

        struct stat st;
        if (stat(full_path, &st) == -1) {
            perror(full_path);
            continue;
        }

        if (S_ISDIR(st.st_mode)) {
            process_directory(full_path, global_table, global_total_words, file_list_head, file_list_tail);
        } else if (S_ISREG(st.st_mode)) {
            char *ext = strrchr(entry->d_name, '.');
            if (ext && strcmp(ext, ".txt") == 0) {
                process_file(full_path, global_table, global_total_words, file_list_head, file_list_tail);
            }
        }
    }

    closedir(dir);
}

void process_directory(const char *path, struct HashTable *global_table, size_t *global_total_words, struct FileData **file_list_head, struct FileData **file_list_tail) {
    traverse_directory(path, global_table, global_total_words, file_list_head, file_list_tail);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s [file or directory...]\n", argv[0]);
        return 1;
    }

    struct HashTable *global_table = create_hash_table(HASH_TABLE_SIZE);
    size_t global_total_words = 0;
    struct FileData *file_list_head = NULL;
    struct FileData *file_list_tail = NULL;

    for (int i = 1; i < argc; i++) {
        const char *path = argv[i];
        struct stat st;
        if (stat(path, &st) == -1) {
            perror(path);
            continue;
        }

        if (S_ISDIR(st.st_mode)) {
            process_directory(path, global_table, &global_total_words, &file_list_head, &file_list_tail);
        } else {
            process_file(path, global_table, &global_total_words, &file_list_head, &file_list_tail);
        }
    }

    struct FileData *current = file_list_head;
    while (current) {
        const char *filename = current->filename;
        struct HashTable *word_counts = current->word_counts;
        size_t file_total = current->total_words;

        double max_ratio = -1.0;
        char *max_word = NULL;

        for (int i = 0; i < word_counts->size; i++) {
            struct Node *node = word_counts->buckets[i];
            while (node) {
                const char *word = node->word;
                int count_in_file = node->count;

                struct Node *global_node = hash_table_find(global_table, word);
                if (!global_node) continue;

                double file_freq = (double)count_in_file / file_total;
                double global_freq = (double)global_node->count / global_total_words;
                double ratio = file_freq / global_freq;

                if (max_word == NULL) {
                    max_ratio = ratio;
                    max_word = (char *)word;
                } else if (ratio > max_ratio || (ratio == max_ratio && strcmp(word, max_word) < 0)) {
                    max_ratio = ratio;
                    max_word = (char *)word;
                }

                node = node->next;
            }
        }

        if (max_word) {
            printf("%s: %s\n", filename, max_word);
        }

        current = current->next;
    }

    // Cleanup
    while (file_list_head) {
        struct FileData *next = file_list_head->next;
        free(file_list_head->filename);
        free_hash_table(file_list_head->word_counts);
        free(file_list_head);
        file_list_head = next;
    }

    free_hash_table(global_table);

    return 0;
}