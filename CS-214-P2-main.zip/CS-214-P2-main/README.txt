Zixin Shi, NetID: zs391
Yue Yao, NetID: yy730

Data Structures
  1. Hash Table:
    A custom hash table is used to store word frequencies. We use a separate chaining method with linked lists to handle hash collisions.
    Node: Each node in the hash table contains a word, its frequency count, and a pointer to the next node in case of collisions.
    The hash table is created with a fixed size (HASH_TABLE_SIZE), which is chosen to balance memory usage and the likelihood of collisions.
  2. FileData Structure:
    A linked list of FileData structures is maintained. Each FileData contains:
    A file name.
    A hash table storing the word counts for that particular file.
    The total number of words in the file.
    A pointer to the next FileData in the list.
    This structure helps to efficiently track the word frequency of each file while also managing memory usage.

Functions
  1. File Processing: Each file is read in its entirety, and its contents are tokenized. Words are extracted, cleaned (converted to lowercase, forbidden punctuation stripped), and counted. These counts are stored in both a local hash table for the file and a global hash table for all files.
  2. Directory Traversal: The program recursively traverses directories and processes .txt files. It supports both individual files and directories containing text files.
  3. Word Frequency Calculation: After processing all files, the program calculates the most "outlier" word for each file. This word has the highest frequency ratio between its frequency in the file and its frequency in all files.

Memory Management
  Memory is dynamically allocated for storing file contents, words, and hash tables. Once processing is complete, all dynamically allocated memory is freed to avoid memory leaks.

Testing Strategy
1. Test Case 1: Basic Example
  Files:
    A.txt: spam eggs bacon spam
    B.txt: spam spam spam
    C.txt: spam eggs beans
  Expected Output:
    A.txt: bacon
    B.txt: spam
    C.txt: beans
2. Test Case 2: Directory Traversal
    Directory Structure:
      testdir/
      ├── a.txt
      ├── b.dat
      └── subdir/
          └── c.txt
  Create the directory and files:
    mkdir -p testdir/subdir
    echo "hello world" > testdir/a.txt
    echo "data file" > testdir/b.dat
    echo "another file" > testdir/subdir/c.txt
  Expected Output:
    testdir/a.txt: hello   # or "world" depending on global frequency
    testdir/subdir/c.txt: another   # or "file"

3. Test Case 3: Punctuation and Case Handling
  File: 
    D.txt: (Hello World! 'This' is a test.)
  Verify:
    Words like hello, world, this, is, a, test are processed.
    Check output for the word with the highest relative frequency.

4. Test Case 4: Empty File
  File: 
    empty.txt (empty)
  Expected Output: 
    No output (empty files are ignored).

5. Test Case 5: Lexicographical Tie
  File: 
    tie.txt: cat apple
  Expected Output:
    tie.txt: apple   # lexicographically smaller

6. Test Case 6: Non-Existent File
  Expected Behavior:
    Error message printed to stderr (missing.txt: No such file or directory).

7. Test Case 7: Large File
  File:
    Generate a large file (1 million lines): "test word", with one more "test"
  Expected Output:
    large.txt: test

8. Test Case 8: Mixed File Types
  Files:
    F.txt: valid .txt file
    G.dat: non-txt file
  Expected Output:
    F.txt: .txt
    G.dat: non-txt

9. Test Case 9: Hidden Files
  Directory: 
    .hiddendir/ with .hiddenfile.txt
  Expected Output: 
    No output (hidden files/directories are ignored).

10. Test Case 10: Mixed File Types in Directory
Directory Structure:
p2/
├── file1.txt           # valid
├── file2.dat           # ignored
├── notes.docx          # ignored
├── summary.txt         # valid
└── subfolder/
    ├── inner1.txt      # valid
    └── image.png       # ignored
Contents:
file1.txt: hello world world
summary.txt: summary summary test
inner1.txt: inner inner inner test
Non-.txt files are ignored.
Expected Output:
file1.txt: hello
summary.txt: test
inner1.txt: inner

11. Test Case 11: Messy Text
File: 
  messy.txt:
    Hello, HELLO... world?! teSt test, Test! again, again.
  hello_again.txt:
    hello hello again again
  hello_again2.txt:
    hello again hello again
Expected Output:
messy.txt: test

12. Test Case 12: Stress Test with Many Files
Directory: p2/ containing 1000 .txt files
Content:
Most files contain: apple banana orange
Some files are modified to create frequency skew:
file_0001.txt: apple apple apple
file_0002.txt: orange orange orange
Expected Output:
file_0001.txt: apple
file_0002.txt: orange
