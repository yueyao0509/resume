#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <math.h> 

#define MAX_WORD 100
#define MAX_PATH 1000

typedef struct word_freq {
    char *word;
    int freq;
} wordfreq;

typedef struct {
    char filename[MAX_PATH];
    wordfreq *words;
    int word_count;
    int total_words;
} FileDatta;

FileDatta *file_data = NULL;
int file_count = 0;

void process_path(const char* path);
void process_file(const char *filename);
void process_directory(const char *dirname);
void add_word(FileDatta *file, const char *word);
double get_overall_frequency(const char *word);
void find_outlier_word(FileDatta *file);
void to_lowercase(char *str);
int is_valid_word(const char *word);
void clean_word(char *word);
void free_memory();

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "FAIL!\nUsage: outlier <directory>\n");
        return EXIT_FAILURE;
    }

    for (int i = 1; i < argc; i++) {
        process_path(argv[i]);
    }

    for (int j = 0; j < file_count; j++) {
        find_outlier_word(&file_data[j]);
    }
    free_memory();
    return 0;
}

void process_directory(const char *dirname) {
    DIR *dir = opendir(dirname);
    if (!dir) {
        perror("opendir");
        return;
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_name[0] == '.') continue;
        char path[MAX_PATH];
        snprintf(path, sizeof(path), "%s/%s", dirname, entry->d_name);
        process_path(path);
    }
    closedir(dir);
}

void process_path(const char* path) {
    struct stat path_stat;
    if (stat(path, &path_stat)) {
        perror("stat");
        return;
    }

    if (S_ISDIR(path_stat.st_mode)) {
        process_directory(path);
    } else {
        process_file(path);
    }
}

void process_file(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("fopen");
        return;
    }

    file_data = realloc(file_data, (file_count + 1) * sizeof(FileDatta));
    if (!file_data) {
        perror("realloc");
        exit(EXIT_FAILURE);
    }

    FileDatta *file = &file_data[file_count];
    strncpy(file->filename, filename, MAX_PATH - 1);
    file->filename[MAX_PATH - 1] = '\0';
    file->words = NULL;
    file->word_count = 0;
    file->total_words = 0;

    char buffer[4096], word[MAX_WORD];
    int index = 0;
    while (fgets(buffer, sizeof(buffer), fp)) {
        for (int i = 0; buffer[i]; i++) {
            if (isspace(buffer[i]) || ispunct(buffer[i])) {
                if (index > 0) {
                    word[index] = '\0';
                    clean_word(word);
                    if (is_valid_word(word)) {
                        to_lowercase(word);
                        add_word(file, word);
                    }
                    index = 0;
                }
            } else {
                if (index < MAX_WORD - 1) {
                    word[index++] = buffer[i];
                }
            }
        }
    }

    // Check for the last word in the file
    if (index > 0) {
        word[index] = '\0';
        clean_word(word);
        if (is_valid_word(word)) {
            to_lowercase(word);
            add_word(file, word);
        }
    }

    fclose(fp);
    file_count++;
}

void add_word(FileDatta *file, const char *word) {
    for (int i = 0; i < file->word_count; i++) {
        if (strcmp(file->words[i].word, word) == 0) {
            file->words[i].freq++;
            file->total_words++;
            return;
        }
    }

    wordfreq *temp = realloc(file->words, (file->word_count + 1) * sizeof(wordfreq));
    if (!temp) {
        perror("realloc");
        exit(EXIT_FAILURE);
    }
    file->words = temp;

    file->words[file->word_count].word = strdup(word);
    if (!file->words[file->word_count].word) {
        perror("strdup");
        exit(EXIT_FAILURE);
    }
    file->words[file->word_count].freq = 1;
    file->word_count++;
    file->total_words++;
}

double get_overall_frequency(const char *word) {
    int total_count = 0, total_words = 0;
    for (int i = 0; i < file_count; i++) {
        for (int j = 0; j < file_data[i].word_count; j++) {
            if (strcmp(file_data[i].words[j].word, word) == 0) {
                total_count += file_data[i].words[j].freq;
            }
        }
        total_words += file_data[i].total_words;
    }
    return total_words > 0 ? (double)total_count / total_words : 0.0;
}

void find_outlier_word(FileDatta *file) {
    double max_ratio = 0.0;
    char *outlier_word = NULL;

    for (int i = 0; i < file->word_count; i++) {
        double file_freq = (double)file->words[i].freq / file->total_words;
        double overall_freq = get_overall_frequency(file->words[i].word);
        double ratio = (overall_freq > 0) ? (file_freq / overall_freq) : (file_freq > 0 ? INFINITY : 0.0);

        if (ratio > max_ratio || (ratio == max_ratio && outlier_word && strcmp(file->words[i].word, outlier_word) < 0)) {
            max_ratio = ratio;
            outlier_word = file->words[i].word;
        }
    }

    if (outlier_word) {
        printf("%s: %s\n", file->filename, outlier_word);
    }
}

void to_lowercase(char *str) {
    for (int i = 0; str[i]; i++) {
        str[i] = tolower(str[i]);
    }
}

int is_valid_word(const char *word) {
    if (word[0] == '\0') return 0; // Check empty string
    for (int i = 0; word[i]; i++) {
        if (!isalpha(word[i]) && word[i] != '-') {
            return 0;
        }
    }
    return 1;
}

void clean_word(char *word) {
    int len = strlen(word);
    while (len > 0 && ispunct(word[len - 1])) {
        word[len - 1] = '\0';
        len--;
    }
}

void free_memory() {
    for (int i = 0; i < file_count; i++) {
        FileDatta *file = &file_data[i];
        for (int j = 0; j < file->word_count; j++) {
            free(file->words[j].word);
        }
        free(file->words);
    }
    free(file_data);
}
