#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <stdbool.h>

#define MAX_PLAYERS 100
#define BUFFER_SIZE 1024

typedef enum { ROCK, PAPER, SCISSORS, NONE } Move;
typedef enum { WAITING, PLAYING, RESULT } PlayerState;

typedef struct {
    int socket;
    char name[50];
    Move move;
    PlayerState state;
    bool wants_rematch;
    pthread_mutex_t lock;
} Player;

typedef struct {
    Player *player1;
    Player *player2;
    bool active;
    pthread_mutex_t lock;
} Game;

Player players[MAX_PLAYERS];
Game games[MAX_PLAYERS / 2];
int player_count = 0;
int game_count = 0;
pthread_mutex_t players_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t games_mutex = PTHREAD_MUTEX_INITIALIZER;

void send_message(int socket, const char *type, const char *arg) {
    char message[BUFFER_SIZE];
    if (arg == NULL || strlen(arg) == 0) {
        snprintf(message, BUFFER_SIZE, "%s||", type);
    } else {
        snprintf(message, BUFFER_SIZE, "%s|%s||", type, arg);
    }
    send(socket, message, strlen(message), 0);
}

Move parse_move(const char *move_str) {
    if (strcmp(move_str, "ROCK") == 0) return ROCK;
    if (strcmp(move_str, "PAPER") == 0) return PAPER;
    if (strcmp(move_str, "SCISSORS") == 0) return SCISSORS;
    return NONE;
}

void determine_winner(Game *game) {
    Move m1 = game->player1->move;
    Move m2 = game->player2->move;

    if (m1 == m2) {
        send_message(game->player1->socket, "R", "D|");
        send_message(game->player2->socket, "R", "D|");
    } else if ((m1 == ROCK && m2 == SCISSORS) ||
               (m1 == PAPER && m2 == ROCK) ||
               (m1 == SCISSORS && m2 == PAPER)) {
        send_message(game->player1->socket, "R", "W|");
        send_message(game->player2->socket, "R", "L|");
    } else {
        send_message(game->player1->socket, "R", "L|");
        send_message(game->player2->socket, "R", "W|");
    }

    game->player1->state = RESULT;
    game->player2->state = RESULT;
}

void *handle_client(void *arg) {
    int client_socket = *((int *)arg);
    free(arg);

    char buffer[BUFFER_SIZE];
    int bytes_read;
    Player *current_player = NULL;
    Game *current_game = NULL;

    pthread_mutex_lock(&players_mutex);
    for (int i = 0; i < player_count; i++) {
        if (players[i].socket == -1) {
            current_player = &players[i];
            break;
        }
    }
    if (!current_player && player_count < MAX_PLAYERS) {
        current_player = &players[player_count++];
        pthread_mutex_init(&current_player->lock, NULL);
    }
    if (current_player) {
        current_player->socket = client_socket;
        current_player->state = WAITING;
        current_player->move = NONE;
        current_player->wants_rematch = false;
    }
    pthread_mutex_unlock(&players_mutex);

    if (!current_player) {
        close(client_socket);
        return NULL;
    }

    while ((bytes_read = recv(client_socket, buffer, BUFFER_SIZE - 1, 0)) > 0) {
        buffer[bytes_read] = '\0';
        printf("Received: %s\n", buffer);
        char *token = strtok(buffer, "|");
        if (!token) continue;

        if (strcmp(token, "P") == 0) {
            char *name = strtok(NULL, "|");
            if (name) {
                strncpy(current_player->name, name, sizeof(current_player->name) - 1);
                send_message(client_socket, "W", "1");

                pthread_mutex_lock(&games_mutex);
                for (int i = 0; i < game_count; i++) {
                    if (games[i].active && (games[i].player1 == NULL || games[i].player2 == NULL)) {
                        if (!games[i].player1) games[i].player1 = current_player;
                        else games[i].player2 = current_player;
                        current_game = &games[i];
                        break;
                    }
                }
                if (!current_game && game_count < MAX_PLAYERS / 2) {
                    current_game = &games[game_count++];
                    current_game->player1 = current_player;
                    current_game->player2 = NULL;
                    current_game->active = true;
                    pthread_mutex_init(&current_game->lock, NULL);
                }
                pthread_mutex_unlock(&games_mutex);

                if (current_game && current_game->player1 && current_game->player2) {
                    current_player->state = PLAYING;
                    send_message(current_game->player1->socket, "B", current_game->player2->name);
                    send_message(current_game->player2->socket, "B", current_game->player1->name);
                }
            }
        } else if (strcmp(token, "M") == 0) {
            char *move_str = strtok(NULL, "|");
            if (move_str && current_game) {
                Move move = parse_move(move_str);
                if (move != NONE) {
                    pthread_mutex_lock(&current_player->lock);
                    current_player->move = move;
                    pthread_mutex_unlock(&current_player->lock);

                    pthread_mutex_lock(&current_game->lock);
                    if (current_game->player1->move != NONE && current_game->player2->move != NONE) {
                        determine_winner(current_game);
                        current_game->player1->move = NONE;
                        current_game->player2->move = NONE;
                    }
                    pthread_mutex_unlock(&current_game->lock);
                }
            }
        } else if (strcmp(token, "C") == 0 && current_game) {
            pthread_mutex_lock(&current_player->lock);
            current_player->wants_rematch = true;
            pthread_mutex_unlock(&current_player->lock);

            pthread_mutex_lock(&current_game->lock);
            bool both = current_game->player1->wants_rematch && current_game->player2->wants_rematch;
            bool quit = !current_game->player1->wants_rematch || !current_game->player2->wants_rematch;

            if (both) {
                current_game->player1->wants_rematch = false;
                current_game->player2->wants_rematch = false;
                current_game->player1->state = PLAYING;
                current_game->player2->state = PLAYING;
                send_message(current_game->player1->socket, "B", current_game->player2->name);
                send_message(current_game->player2->socket, "B", current_game->player1->name);
            } else if (quit) {
                if (!current_game->player1->wants_rematch) close(current_game->player1->socket);
                if (!current_game->player2->wants_rematch) close(current_game->player2->socket);
                current_game->active = false;
            }
            pthread_mutex_unlock(&current_game->lock);
        } else if (strcmp(token, "Q") == 0 && current_game) {
            pthread_mutex_lock(&current_game->lock);
            if (current_game->player1 == current_player && current_game->player2) {
                send_message(current_game->player2->socket, "R", "F|");
                close(current_game->player2->socket);
            } else if (current_game->player1) {
                send_message(current_game->player1->socket, "R", "F|");
                close(current_game->player1->socket);
            }
            current_game->active = false;
            pthread_mutex_unlock(&current_game->lock);
            break;
        }
    }

    if (current_player) current_player->socket = -1;
    close(client_socket);
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        exit(1);
    }

    int port = atoi(argv[1]);
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    struct sockaddr_in server_addr = {0};
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);

    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        exit(1);
    }

    if (listen(server_socket, 5) < 0) {
        perror("Listen failed");
        exit(1);
    }

    printf("Server listening on port %d...\n", port);

    while (1) {
        struct sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);
        int client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_len);
        if (client_socket < 0) {
            perror("Accept failed");
            continue;
        }

        pthread_t thread;
        int *sock_ptr = malloc(sizeof(int));
        *sock_ptr = client_socket;
        if (pthread_create(&thread, NULL, handle_client, sock_ptr) != 0) {
            perror("Thread creation failed");
            close(client_socket);
            free(sock_ptr);
        }
    }

    close(server_socket);
    return 0;
}
