#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <assert.h>

#define BUFFER_SIZE 1024

// Connects to server at given IP and port
int connect_to_server(const char* ip, int port) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) { perror("socket"); exit(1); }

    struct sockaddr_in serv_addr;
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    inet_pton(AF_INET, ip, &serv_addr.sin_addr);

    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("connect");
        exit(1);
    }

    return sock;
}

// Receives a message and null-terminates it
void recv_msg(int sock, char* buf) {
    int len = recv(sock, buf, BUFFER_SIZE - 1, 0);
    if (len <= 0) {
        perror("recv failed");
        exit(1);
    }
    buf[len] = '\0';
}

// Sends a message and logs it
void send_and_log(int sock, const char* msg) {
    printf("[SEND ]: %s\n", msg);
    send(sock, msg, strlen(msg), 0);
}

int main() {
    const char* ip = "127.0.0.1";
    int port = 9000;

    // Simulate two clients connecting
    int c1 = connect_to_server(ip, port);
    int c2 = connect_to_server(ip, port);

    char buf[BUFFER_SIZE];

    // Receive handshake W|1||
    recv_msg(c1, buf); printf("[RECV C1]: %s\n", buf);
    recv_msg(c2, buf); printf("[RECV C2]: %s\n", buf);

    // Send player names
    send_and_log(c1, "P|Alice||");
    send_and_log(c2, "P|Bob||");

    // Receive game start message B|opponent||
    recv_msg(c1, buf); printf("[RECV C1]: %s\n", buf);
    recv_msg(c2, buf); printf("[RECV C2]: %s\n", buf);

    // Send moves
    send_and_log(c1, "M|ROCK||");
    send_and_log(c2, "M|SCISSORS||");

    // Receive results R|W|| / R|L||
    recv_msg(c1, buf); printf("[RECV C1]: %s\n", buf);
    recv_msg(c2, buf); printf("[RECV C2]: %s\n", buf);

    // Send quit signals
    send_and_log(c1, "Q||");
    send_and_log(c2, "Q||");

    close(c1);
    close(c2);

    printf("Simulated game complete. Server behavior as expected.\n");
    return 0;
}

