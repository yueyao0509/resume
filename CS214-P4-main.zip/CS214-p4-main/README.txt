CS214 Project 4: Rock-Paper-Scissors Server
===========================================

Authors:
- Zixin Shi (NetID: zs391) Yue Yao (NetID: yy730)

Server Type
-----------
This server supports **concurrent games**. Multiple pairs of players can connect and play independently, using POSIX threads (pthreads) to handle each client.

Implemented Files
-----------------

1. rpsd.c  
   - The main implementation of the `rpsd` server.
   - Accepts TCP connections on a specified port.
   - Matches clients into games, exchanges names, receives moves, determines results, and handles rematch or quit messages.
   - Supports forfeits if a player disconnects without sending a move.
   - Thread-safe, using mutexes to protect shared data.

2. rpsd_client.c  
   - A custom command-line client to interact with the server.
   - Sends protocol-compliant messages (`P|name||`, `M|ROCK||`, etc.)
   - Allows users to type commands (`rock`, `paper`, `scissors`, `continue`, `quit`) during play.

3. test_rps.c  
   - An automated testing program that launches the server in a thread and simulates client behavior.
   - Includes a variety of tests:
     - Name registration
     - Single-player waiting
     - Two-player matches
     - Rematch and quit flows
     - Tie cases
     - Concurrent 4-player tests (2 games at once)
     - Forfeit detection and recovery

Test Plan
---------
- Manual testing was done using `rpsd_client`, verifying that all protocol messages are handled correctly.
- Automated tests in `test_rps.c` verify:
  - Protocol compliance
  - Server concurrency
  - Result correctness (Win/Loss/Draw)
  - Stability on disconnects
  - Rematch behavior

Build Instructions
------------------

To compile all components:

```
make
```

This will build:
- `rpsd` – the main server
- `rpsd_client` – interactive client
- `test_rps` – automated test runner

Usage
-----

Start server:
```
./rpsd <port>
```

Start client:
```
./rpsd_client <host> <port> [player_name]
```

Run automated tests:
```
./test_rps
```

Notes
-----
- Protocol strictly follows the project spec, using messages like:
  - `P|Alice||`  
  - `M|ROCK||`  
  - `R|W|SCISSORS||`
- Messages are delimited by `|` and terminated by `||`, as required.