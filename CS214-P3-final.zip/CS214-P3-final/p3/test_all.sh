#!/bin/bash
set -eo pipefail

TEST_DIR="test_tmp"
mkdir -p "$TEST_DIR"
cd "$TEST_DIR"

cleanup() {
    cd ..
    rm -rf "$TEST_DIR"
}
trap cleanup EXIT

test_case() {
    local test_num=$1
    local description=$2
    shift 2
    echo -n "Test $test_num: $description... "
    if "$@" >/dev/null 2>&1; then
        echo "PASS"
    else
        echo "FAIL"
        exit 1
    fi
}

# Test 1: Interactive mode messages
test_case 1 "Interactive mode messages" bash -c '
    tmpfile=$(mktemp)
    echo "exit" | ../mysh > "$tmpfile" 2>&1
    grep -q "mysh> " "$tmpfile" 
    rm "$tmpfile"
'

# Test 2: Batch mode silence
test_case 2 "Batch mode silence" bash -c '
    echo "echo test" > script.sh
    [ $(../mysh < script.sh | wc -l) -eq 1 ] &&
    [ $(echo "echo test" | ../mysh | wc -l) -eq 1 ]
'

# Test 3: cd command
test_case 3 "cd command" bash -c '
    mkdir test_dir
    (echo "cd test_dir"; echo "pwd") | ../mysh | grep -q "test_dir" &&
    (echo "cd invalid_dir") | ../mysh 2>&1 | grep -q "No such file"
'

# Test 4: pwd command
test_case 4 "pwd command" bash -c '
    [ "$(echo "pwd" | ../mysh)" = "$PWD" ]
'

# Test 5: exit command
test_case 5 "exit command" bash -c '
    echo "exit 42" | ../mysh
    [ $? -eq 42 ]
'

# Test 6: Wildcard expansion
test_case 6 "Wildcard expansion" bash -c '
    touch file1.txt file2.txt .hidden.txt
    echo "echo *.txt" | ../mysh | grep -q "file1.txt file2.txt" &&
    echo "echo *nonexist*" | ../mysh | grep -q "*nonexist*" &&
    echo "echo ./*.txt" | ../mysh | grep -qv ".hidden.txt"
'

# Test 7: Redirection
test_case 7 "Redirection" bash -c '
    echo "content" > input.txt
    echo "cat < input.txt" | ../mysh | grep -q "content" &&
    echo "echo test > output.txt" | ../mysh && grep -q test output.txt &&
    echo "echo append >> output.txt" | ../mysh && [ $(wc -l < output.txt) -eq 2 ]
'

# Test 8: Pipes
test_case 8 "Pipes" bash -c '
    seq 3 > numbers.txt
    echo "cat numbers.txt | grep 2" | ../mysh | grep -q "2"
'

# Test 9: Error handling
test_case 9 "Error handling" bash -c '
    (echo "invalid_cmd" | ../mysh 2>&1) | grep -q "command not found" &&
    (echo "echo < <" | ../mysh 2>&1) | grep -q "syntax error"
'

# Test 10: Edge cases
test_case 10 "Edge cases" bash -c '
    echo "# comment" | ../mysh | wc -l | grep -q 0
'

echo "===== All 10 tests passed successfully ====="