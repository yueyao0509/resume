#!/bin/bash
echo "===== Starting Tests ====="

test_case() {
  echo -n "$1... "
  shift
  if "$@" >/dev/null 2>&1; then
    echo "PASS"
  else
    echo "FAIL"
  fi
}

# Test 1: Output Redirection
echo "Hello" > test_output.txt
test_case "Output Redirection" grep -q "Hello" test_output.txt
rm test_output.txt

# Test 2: Wildcard Expansion
touch a.txt b.txt
./mysh <<EOF > wildcard_test.txt
echo *.txt
exit
EOF
test_case "Wildcard Expansion" grep -q "a.txt b.txt" wildcard_test.txt
rm a.txt b.txt wildcard_test.txt

# Test 3: Pipeline
ls | grep "mysh" > pipeline_test.txt
test_case "Pipeline" grep -q "mysh" pipeline_test.txt
rm pipeline_test.txt

echo "===== Tests Complete ====="