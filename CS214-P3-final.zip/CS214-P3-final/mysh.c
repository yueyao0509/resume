#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <fnmatch.h>
#include <errno.h>
#include <stdbool.h>
#include <limits.h>
#include <signal.h>
#include <glob.h>

#define INITIAL_CAPACITY 16
#define MAX_PIPES 10

typedef struct {
    char **args;
    int argc;
    int capacity;
    char *input_file;
    char *output_file;
    bool append;
} Command;

typedef struct {
    Command *cmds;
    int count;
    bool conditional_and;
    bool conditional_or;
} Pipeline;

volatile sig_atomic_t child_pid = -1;
volatile sig_atomic_t interrupted = 0;
int last_command_status = 0;

void handle_sigint() {
    if (child_pid > 0) {
        kill(child_pid, SIGINT);
    }
    interrupted = 1;
}

void init_shell() {
    struct sigaction sa;
    sa.sa_handler = handle_sigint;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGINT, &sa, NULL);
    signal(SIGQUIT, SIG_IGN);
}

char *find_executable(const char *cmd) {
    if (strchr(cmd, '/') != NULL) {
        if (access(cmd, X_OK) == 0) {
            return strdup(cmd);
        }
        return NULL;
    }

    const char *search_paths[] = {"/usr/local/bin", "/usr/bin", "/bin"};
    for (int i = 0; i < 3; i++) {
        char *path = malloc(strlen(search_paths[i]) + strlen(cmd) + 2);
        sprintf(path, "%s/%s", search_paths[i], cmd);
        if (access(path, X_OK) == 0) {
            return path;
        }
        free(path);
    }
    return NULL;
}

void expand_wildcards(Command *cmd) {
    glob_t globbuf;
    int new_argc = 0;
    char **new_args = malloc(cmd->capacity * sizeof(char *));

    for (int i = 0; i < cmd->argc; i++) {
        if (strpbrk(cmd->args[i], "*?[")) {
            if (glob(cmd->args[i], GLOB_TILDE, NULL, &globbuf) == 0) {
                for (size_t j = 0; j < globbuf.gl_pathc; j++) {
                    if (new_argc >= cmd->capacity) {
                        cmd->capacity *= 2;
                        new_args = realloc(new_args, cmd->capacity * sizeof(char *));
                    }
                    new_args[new_argc++] = strdup(globbuf.gl_pathv[j]);
                }
                globfree(&globbuf);
                continue;
            }
        }
        if (new_argc >= cmd->capacity) {
            cmd->capacity *= 2;
            new_args = realloc(new_args, cmd->capacity * sizeof(char *));
        }
        new_args[new_argc++] = strdup(cmd->args[i]);
    }

    for (int i = 0; i < cmd->argc; i++) {
        free(cmd->args[i]);
    }
    free(cmd->args);

    cmd->args = new_args;
    cmd->argc = new_argc;
}

char **tokenize(const char *line, int *count) {
    char **tokens = NULL;
    int capacity = INITIAL_CAPACITY;
    *count = 0;

    tokens = malloc(capacity * sizeof(char *));
    if (!tokens) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }

    char *copy = strdup(line);
    char *current = copy;
    char quote = 0;
    bool in_comment = false;

    while (*current) {
        if (*current == '#') {
            in_comment = true;
            current++;
            continue;
        }
        if (in_comment) {
            if (*current == '\n') {
                in_comment = false;
            }
            current++;
            continue;
        }

        while (*current && (*current == ' ' || *current == '\t' || *current == '\n')) {
            current++;
        }
        if (!*current) break;

        char *start = current;
        if (*current == '\'' || *current == '"') {
            quote = *current;
            start = ++current;
            while (*current && *current != quote) {
                current++;
            }
        } else {
            while (*current && *current != ' ' && *current != '\t' && *current != '\n') {
                current++;
            }
        }

        size_t len = current - start;
        if (quote) {
            if (*current == quote) current++;
            quote = 0;
        }

        char *token = strndup(start, len);
        if (!token) {
            perror("strndup");
            exit(EXIT_FAILURE);
        }

        if (*count >= capacity) {
            capacity *= 2;
            tokens = realloc(tokens, capacity * sizeof(char *));
            if (!tokens) {
                perror("realloc");
                exit(EXIT_FAILURE);
            }
        }
        tokens[(*count)++] = token;

        if (*current) current++;
    }

    free(copy);
    return tokens;
}

void parse_command(char **tokens, int count, Command *cmd) {
    cmd->args = malloc(INITIAL_CAPACITY * sizeof(char *));
    cmd->argc = 0;
    cmd->capacity = INITIAL_CAPACITY;
    cmd->input_file = NULL;
    cmd->output_file = NULL;
    cmd->append = false;

    for (int i = 0; i < count; i++) {
        if (strcmp(tokens[i], "<") == 0 || strcmp(tokens[i], ">") == 0 || 
            strcmp(tokens[i], ">>") == 0) {
            if (i+1 >= count) {
                fprintf(stderr, "syntax error near unexpected token `%s'\n", tokens[i]);
                exit(1);
            }
            if (tokens[i+1][0] == '<' || tokens[i+1][0] == '>') {
                fprintf(stderr, "syntax error near unexpected token `%s'\n", tokens[i+1]);
                exit(1);
            }
        }
    }

    for (int i = 0; i < count; i++) {
        if (strcmp(tokens[i], "<") == 0 && i+1 < count) {
            free(cmd->input_file);
            cmd->input_file = strdup(tokens[++i]);
        } else if (strcmp(tokens[i], ">") == 0 && i+1 < count) {
            free(cmd->output_file);
            cmd->output_file = strdup(tokens[++i]);
        } else if (strcmp(tokens[i], ">>") == 0 && i+1 < count) {
            free(cmd->output_file);
            cmd->output_file = strdup(tokens[++i]);
            cmd->append = true;
        } else {
            if (cmd->argc >= cmd->capacity) {
                cmd->capacity *= 2;
                cmd->args = realloc(cmd->args, cmd->capacity * sizeof(char *));
            }
            cmd->args[cmd->argc++] = strdup(tokens[i]);
        }
    }
    
    expand_wildcards(cmd);
    
    if (cmd->argc >= cmd->capacity) {
        cmd->capacity += 1;
        cmd->args = realloc(cmd->args, cmd->capacity * sizeof(char *));
    }
    cmd->args[cmd->argc] = NULL;
}

int handle_builtin(Command *cmd) {
    if (cmd->argc == 0) return -1;

    if (strcmp(cmd->args[0], "cd") == 0) {
        if (cmd->argc > 2) {
            fprintf(stderr, "cd: too many arguments\n");
            return 1;
        }
        char *dir = cmd->argc > 1 ? cmd->args[1] : getenv("HOME");
        if (chdir(dir) != 0) {
            perror("cd");
            return 1;
        }
        return 0;
    }
    if (strcmp(cmd->args[0], "pwd") == 0) {
        char cwd[PATH_MAX];
        if (getcwd(cwd, sizeof(cwd))) {
            printf("%s\n", cwd);
            return 0;
        }
        perror("pwd");
        return 1;
    }
    if (strcmp(cmd->args[0], "which") == 0) {
        if (cmd->argc != 2) {
            fprintf(stderr, "which: requires exactly one argument\n");
            return 1;
        }
        char *path = find_executable(cmd->args[1]);
        if (path) {
            printf("%s\n", path);
            free(path);
            return 0;
        }
        return 1;
    }
    if (strcmp(cmd->args[0], "exit") == 0) {
        printf("Exiting my shell.\n");
        return cmd->argc > 1 ? atoi(cmd->args[1]) : 0;
    }
    if (strcmp(cmd->args[0], "die") == 0) {
        if (cmd->argc > 1) {
            for (int i = 1; i < cmd->argc; i++) {
                fprintf(stderr, "%s%s", cmd->args[i], i == cmd->argc - 1 ? "\n" : " ");
            }
        } else {
            fprintf(stderr, "Dying by request\n");
        }
        return 1;
    }
    return -1;
}

int execute_command(Command *cmd) {
    if (!cmd || cmd->argc == 0) return -1;
    
    int builtin_status = handle_builtin(cmd);
    if (builtin_status >= 0) {
        return builtin_status;
    }

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return -1;
    }

    if (pid == 0) {
        if (cmd->input_file) {
            int fd = open(cmd->input_file, O_RDONLY);
            if (fd < 0) {
                perror("open");
                exit(EXIT_FAILURE);
            }
            dup2(fd, STDIN_FILENO);
            close(fd);
        }
        if (cmd->output_file) {
            int flags = O_WRONLY|O_CREAT| (cmd->append ? O_APPEND : O_TRUNC);
            int fd = open(cmd->output_file, flags, 0640);
            if (fd < 0) {
                perror("open");
                exit(EXIT_FAILURE);
            }
            dup2(fd, STDOUT_FILENO);
            close(fd);
        }

        char *path = strchr(cmd->args[0], '/') ? cmd->args[0] : find_executable(cmd->args[0]);
        if (!path) {
            fprintf(stderr, "%s: command not found\n", cmd->args[0]);
            exit(127);
        }

        execv(path, cmd->args);
        perror("execv");
        exit(126);
    } else {
        child_pid = pid;
        int status;
        waitpid(pid, &status, 0);
        child_pid = -1;
        return WIFEXITED(status) ? WEXITSTATUS(status) : -1;
    }
}

void execute_pipeline(Pipeline *pipeline) {
    if (!pipeline || pipeline->count <= 0) return;
    
    if (pipeline->conditional_and && last_command_status != 0) {
        return;
    }
    if (pipeline->conditional_or && last_command_status == 0) {
        return;
    }

    int fds[2];
    int prev_fd = -1;
    pid_t *pids = malloc(pipeline->count * sizeof(pid_t));
    if (!pids) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < pipeline->count; i++) {
        if (i < pipeline->count - 1) {
            if (pipe(fds) < 0) {
                perror("pipe");
                free(pids);
                exit(EXIT_FAILURE);
            }
        }

        if ((pids[i] = fork()) < 0) {
            perror("fork");
            free(pids);
            exit(EXIT_FAILURE);
        }

        if (pids[i] == 0) {
            if (i > 0) {
                dup2(prev_fd, STDIN_FILENO);
                close(prev_fd);
            }
            
            if (i < pipeline->count - 1) {
                close(fds[0]);
                dup2(fds[1], STDOUT_FILENO);
                close(fds[1]);
            }
            
            int status = execute_command(&pipeline->cmds[i]);
            exit(status);
        } else {
            if (i > 0) close(prev_fd);
            if (i < pipeline->count - 1) {
                prev_fd = fds[0];
                close(fds[1]);
            }
        }
    }

    for (int i = 0; i < pipeline->count; i++) {
        int status;
        waitpid(pids[i], &status, 0);
        if (i == pipeline->count - 1) {
            last_command_status = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
        }
    }
    
    free(pids);
}

void free_command(Command *cmd) {
    if (!cmd) return;
    
    if (cmd->args) {
        for (int i = 0; i < cmd->argc; i++) {
            if (cmd->args[i]) free(cmd->args[i]);
        }
        free(cmd->args);
    }
    if (cmd->input_file) free(cmd->input_file);
    if (cmd->output_file) free(cmd->output_file);
}

void shell_loop(bool interactive) {
    char *line = NULL;
    size_t len = 0;
    ssize_t read;

    while (!interrupted) {
        if (interactive) {
            printf("mysh> ");
            fflush(stdout);
        }

        if ((read = getline(&line, &len, stdin)) <= 0) {
            if (interactive) printf("\n");
            break;
        }

        if (line[read - 1] == '\n') {
            line[read - 1] = '\0';
        }

        int token_count;
        char **tokens = tokenize(line, &token_count);
        
        if (token_count == 0) {
            free(tokens);
            continue;
        }

        // Check for conditionals
        bool conditional_and = false;
        bool conditional_or = false;
        if (strcmp(tokens[0], "and") == 0) {
            conditional_and = true;
            for (int i = 0; i < token_count - 1; i++) {
                tokens[i] = tokens[i+1];
            }
            token_count--;
        } else if (strcmp(tokens[0], "or") == 0) {
            conditional_or = true;
            for (int i = 0; i < token_count - 1; i++) {
                tokens[i] = tokens[i+1];
            }
            token_count--;
        }

        char *pipe_sep = strchr(line, '|');
        
        if (pipe_sep) {
            Pipeline pipeline = {0};
            pipeline.cmds = malloc(MAX_PIPES * sizeof(Command));
            pipeline.conditional_and = conditional_and;
            pipeline.conditional_or = conditional_or;
            
            char *saveptr;
            char *cmd_str = strtok_r(line, "|", &saveptr);
            int cmd_count = 0;

            while (cmd_str && cmd_count < MAX_PIPES) {
                int cmd_token_count;
                char **cmd_tokens = tokenize(cmd_str, &cmd_token_count);
                parse_command(cmd_tokens, cmd_token_count, &pipeline.cmds[cmd_count]);
                
                for (int i = 0; i < cmd_token_count; i++) free(cmd_tokens[i]);
                free(cmd_tokens);
                
                cmd_str = strtok_r(NULL, "|", &saveptr);
                cmd_count++;
            }
            pipeline.count = cmd_count;

            execute_pipeline(&pipeline);

            for (int i = 0; i < cmd_count; i++) {
                free_command(&pipeline.cmds[i]);
            }
            free(pipeline.cmds);
        } else {
            if ((conditional_and && last_command_status != 0) ||
                (conditional_or && last_command_status == 0)) {
                free(tokens);
                continue;
            }

            Command cmd = {0};
            parse_command(tokens, token_count, &cmd);
            
            if (cmd.argc > 0) {
                int status = execute_command(&cmd);
                if (status >= 0 && (strcmp(cmd.args[0], "exit") == 0 || strcmp(cmd.args[0], "die") == 0)) {
                    free_command(&cmd);
                    free(tokens);
                    free(line);
                    exit(status);
                }
                last_command_status = status;
            }
            free_command(&cmd);
        }

        for (int i = 0; i < token_count; i++) free(tokens[i]);
        free(tokens);
        free(line);
        line = NULL;
        len = 0;
    }
}

int main(int argc, char *argv[]) {
    init_shell();
    bool interactive = isatty(STDIN_FILENO);

    if (argc > 2) {
        fprintf(stderr, "Usage: %s [script]\n", argv[0]);
        return 1;
    }

    if (argc == 2) {
        FILE *script = fopen(argv[1], "r");
        if (!script) {
            perror("fopen");
            return 1;
        }
        if (dup2(fileno(script), STDIN_FILENO) < 0) {
            perror("dup2");
            return 1;
        }
        fclose(script);
        interactive = false;
    }

    if (interactive) {
        printf("Welcome to my shell!\n");
    }

    shell_loop(interactive);

    if (interactive) {
        printf("Exiting my shell.\n");
    }
    return 0;
}
