#!/bin/bash

echo
echo "====== Test 1: Interactive & Batch Mode ======"

echo "Test 1.1: Interactive Mode (manual)"
echo "-> Please run ./mysh manually and type 'exit' to verify welcome & goodbye messages."

echo "Test 1.2: Batch Mode with File"
echo "echo Hello from file" > test1.sh
./mysh test1.sh
rm test1.sh

echo "Test 1.3: Batch Mode with Stdin"
echo "echo Hello from stdin" | ./mysh

echo
echo "====== Test 2: Built-in Commands ======"

echo "Test 2.1: cd"
mkdir -p tmpdir
echo -e "cd tmpdir\npwd\ncd ..\ncd no_such_dir" > test_cd.sh
./mysh test_cd.sh
rm -r tmpdir test_cd.sh

echo "Test 2.2: pwd"
echo "pwd" | ./mysh

echo "Test 2.3: which"
echo -e "which ls\nwhich notacommand" | ./mysh

echo "Test 2.4: exit (manual)"
echo "-> Run ./mysh, type 'exit', and ensure it terminates properly."

echo "Test 2.5: die"
echo 'die fatal error occurred' > test_die.sh
./mysh test_die.sh || echo "Exited with failure (expected)"
rm test_die.sh

echo
echo "====== Test 3: Wildcards ======"

echo "Test 3.1: Basic wildcard"
touch a.txt b.txt
echo "echo *.txt" > test_wc1.sh
./mysh test_wc1.sh
rm a.txt b.txt test_wc1.sh

echo "Test 3.2: No matches"
echo "echo *.nomatch" | ./mysh

echo "Test 3.3: Hidden files"
touch .hidden.txt
echo "echo *.txt" > test_wc_hidden.sh
./mysh test_wc_hidden.sh
echo "echo .*" | ./mysh
rm .hidden.txt test_wc_hidden.sh

echo "Test 3.4: Multiple wildcards"
touch a1.txt b2.txt
echo "echo a*.txt b*.txt" > test_wc_multi.sh
./mysh test_wc_multi.sh
rm a1.txt b2.txt test_wc_multi.sh

echo
echo "====== Test 4: Redirection ======"

echo "Test 4.1: Input redirection"
echo "Input Line" > input.txt
echo "cat < input.txt" > test_rdin.sh
./mysh test_rdin.sh
rm input.txt test_rdin.sh

echo "Test 4.2: Output redirection"
echo "echo Hello Output > output.txt" > test_rdout.sh
./mysh test_rdout.sh
cat output.txt
rm output.txt test_rdout.sh

echo "Test 4.3: Combined redirection"
echo -e "c\nb\na" > unsorted.txt
echo "sort < unsorted.txt > sorted.txt" > test_sort.sh
./mysh test_sort.sh
cat sorted.txt
rm unsorted.txt sorted.txt test_sort.sh

echo "Test 4.4: Invalid redirection syntax"
echo "echo hi >" | ./mysh
echo "cat < <" | ./mysh

echo
echo "====== Test 5: Pipelines ======"

echo "Test 5.1: Simple pipeline"
echo "ls | grep mysh" > test_pipe1.sh
./mysh test_pipe1.sh
rm test_pipe1.sh

echo "Test 5.2: Pipeline with output redirection"
echo "ls | grep mysh > result.txt" > test_pipe2.sh
./mysh test_pipe2.sh
cat result.txt
rm result.txt test_pipe2.sh

echo "Test 5.3: Built-in in pipeline"
echo "pwd | grep /" > test_pipe3.sh
./mysh test_pipe3.sh
rm test_pipe3.sh

echo
echo "====== Test 6: Conditionals ======"

echo "Test 6.1: false and echo"
echo "false and echo should_not_run" | ./mysh

echo "Test 6.2: false or echo"
echo "false or echo should_run" | ./mysh

echo "Test 6.3: Sequential and then or"
echo -e "false\nand echo should_not_run\nor echo should_run" > test_63.sh
./mysh test_63.sh
rm test_63.sh

echo "Test 6.4: or die"
echo -e "false\nor die \"fatal condition met\"" > test_die101.sh
./mysh test_die101.sh || echo "Exited as expected"
rm test_die101.sh

echo
echo "====== Test 7: Empty & Comment Lines ======"

echo "Test 7.1: Comment lines"
echo -e "# just a comment\necho Hello # inline" > test_comment.sh
./mysh test_comment.sh
rm test_comment.sh

echo "Test 7.2: Empty lines"
echo -e "\n\necho Not Empty\n\n" > test_empty.sh
./mysh test_empty.sh
rm test_empty.sh

echo
echo "====== Test 8: Invalid Syntax ======"

echo "Test 8.1: Double input redirection"
echo "cat < <" | ./mysh

echo "Test 8.2: Missing output file"
echo "echo hello >" | ./mysh

echo "Test 8.3: Mixed 'and' / 'or' Conditions"
echo -e "echo one\nand echo two\nor echo three" > test_83.sh
./mysh test_83.sh
rm test_83.sh

echo
echo "====== Test 9: Built-in Exit ======"

echo "Test 9.1: exit (manual)"
echo "-> Please run './mysh', type 'exit', and ensure shell exits cleanly."

echo
echo "====== Test 10: Die Command ======"

echo "Test 10.1: 'die' command with message in or"
echo 'false or die "fatal error occurred"' > test_die_or.sh
./mysh test_die_or.sh || echo "Exited as expected"
rm test_die_or.sh

echo
echo "====== Test 11: Redirection Syntax Error ======"

echo "Test 11.1: '>' with missing output file"
echo "echo hello >" > test_redir_err.sh
./mysh test_redir_err.sh
rm test_redir_err.sh

echo
echo "====== ✅ All Tests Completed ======"
echo "Please review the output above for any errors or unexpected behavior."
echo "If all tests passed, your shell is functioning correctly!"
echo "Thank you for testing mysh!"