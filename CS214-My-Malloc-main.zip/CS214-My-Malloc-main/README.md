# CS214-My-Malloc

Zixin Shi, NetID: zs391 

Yue Yao, NetID: yy730

Test Plan:
1. Basic Functionality Tests
    These tests ensure that the basic functionality of mymalloc() and myfree() works as expected. The following tests will confirm that the program correctly allocates and frees memory.
    
    Test 1: Basic Allocation and Freeing
    Description: Test that a single allocation and free operation works properly.
    Steps:
    Allocate a small memory block using malloc().
    Free the allocated memory.
    Expected Outcome: SUCCESS: Memory allocated and freed correctly.
    
    Test 2: Multiple Allocations
    Description: Test multiple consecutive allocations and deallocations.
    Steps:
    Allocate several chunks of memory (e.g., 10 chunks of 32 bytes).
    Free each chunk.
    Expected Outcome: SUCCESS: All memory chunks allocated and freed correctly.
    

2. Error Detection Tests
    These tests ensure that the library can detect and report errors related to memory allocation and freeing. It also checks that invalid calls to free() are correctly handled.
    
    Test 3: Freeing Invalid Pointer
    Description: Test the case where free() is called on a pointer that was not allocated via malloc().
    Steps:
    Declare a local variable (e.g., int x;).
    Call free() on the address of the variable (free(&x)).
    Expected Outcome: The program should report an error message: free: Inappropriate pointer (cor.c:37). and terminate with exit code 2.

    Test 4: Double Freeing
    Description: Test freeing the same pointer twice.
    Steps:
    Allocate a memory block (e.g., 8 bytes).
    Free the memory once.
    Attempt to free the same pointer again.
    Expected Outcome: The program should report an error message: free: It has been freed. (cor.c:55). and terminate with exit code 2.

3. Leak Detection Tests
    These tests ensure that memory leaks are detected correctly.
    
    Test 5: Detecting Leaked Memory
    Description: Test that memory leaks are detected and reported at program exit.
    Steps:
    Allocate some memory blocks using malloc().
    Do not free some or all of the memory blocks.
    Run the program and let it terminate.
    Expected Outcome: The program should print a leak message at the end, e.g., mymalloc: 128 bytes leaked in 14 objects.
   
4. Edge Case Tests
    These tests handle unusual or extreme conditions to ensure robustness.
    
    Test 6: Allocation of Zero Bytes
    Description: Test allocating 0 bytes.
    Steps:
    Call malloc(0).
    Expected Outcome: SUCCESS: malloc(0) returned a valid pointer.
    
    Test 7: Large Allocation
    Description: Test allocating a very large block of memory.
    Steps:
    Request an allocation larger than the available memory (e.g., more than MEMLENGTH).
    Verify that the allocation fails gracefully.
    Expected Outcome: report error message: malloc: Unable to allocate 4096104 bytes (cor.c:97). SUCCESS: Large allocation correctly failed.

5. Coalescing Free Chunks Tests
    These tests verify that adjacent free chunks are coalesced correctly.
    
    Test 8: Coalescing Adjacent Free Chunks
    Description: Test that two adjacent free chunks are correctly coalesced into a larger chunk when a new malloc() request cannot be fulfilled by existing chunks.
    Steps:
    Allocate multiple blocks of memory.
    Free them in a particular order, leaving adjacent free chunks.
    Request a chunk of memory larger than any individual free chunk but smaller than the total of two adjacent chunks.
    Expected Outcome: Success: Coalesced adjacent free chunks and allocated 200 bytes.

   
Stress Test:
A. malloc() and immediately free() a 1-byte object, 120 times.
B. Use malloc() to get 120 1-byte objects, storing the pointers in an array, then use free() to deallocate the chunks.
C. Create an array of 120 pointers. Repeatedly make a random choice between (a) allocating a 1-byte object and adding the pointer to the array and (b) deallocating a previously allocated object (if any). Once 120 allocations have been performed, deallocate all objects.
D. Perform a sequence of malloc() and free() calls with random choices.
Randomly decide whether to allocate memory or free a previously allocated block. Ensure that you never free more blocks than you’ve allocated. After completing the random sequence, free any remaining allocated memory.
E. Allocate blocks of with random size in memory. Free half blocks in random order, making sure to leave gaps between allocations.Try to allocate new blocks that fit into the gaps left by freed blocks, testing whether your implementation can coalesce the fragmented memory.
